namespace Devantler.DataMesh.ProvisioningApi.DTOs;

public class ClusterInfo
{
    public bool IsLocal { get; set; }
    public string? Name { get; set; }
}
