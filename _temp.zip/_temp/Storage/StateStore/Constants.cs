namespace Devantler.DataMesh.DataProduct.Storage.StateStore;

public class Constants
{
    public const string STATE_STORE_FEATURE_FLAG = "StateStore";
}
