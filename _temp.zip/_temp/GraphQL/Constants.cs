namespace Devantler.DataMesh.DataProduct.Apis.GraphQL;

public class Constants
{
    public const string GRAPHQL_FEATURE_FLAG = "GraphQL";
}
